# ReactionRecorder — one-click APK build

This folder is an Android Studio/Kotlin project with a GitHub Actions workflow.

## One-click build
1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root (keep `.github/workflows/build.yml`).
3. Open the repository's **Actions** tab.
4. Select **Build ReactionRecorder APK** and press **Run workflow**. GitHub Actions builds the APK on a hosted runner and uploads `ReactionRecorder-debug-apk` as an artifact.
5. Download the artifact, extract it, and install `app-debug.apk` on Android.

GitHub Actions supports manual workflows and build artifacts. See the official GitHub Actions documentation.

## App behavior
- Select a local video.
- Front/back camera switch before recording.
- 50/50 left-right final composition.
- Original source audio plus microphone audio are composed together.
- Final MP4 is saved to `Movies/ReactionRecorder`.

## Important
This ZIP is a buildable project, not an APK. The current ChatGPT runtime does not have the Android SDK/Gradle build environment needed to compile and test the APK locally. The GitHub workflow is therefore included to perform the build remotely.
