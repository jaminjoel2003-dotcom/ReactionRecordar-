package com.reactionrecorder

import android.app.*
import android.content.Intent
import android.os.IBinder

class RecordingForegroundService : Service() {
    override fun onCreate() { super.onCreate(); createChannel(); startForeground(7, notification()) }
    private fun createChannel() { getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("recording", "Recording", NotificationManager.IMPORTANCE_LOW)) }
    private fun notification(): Notification = Notification.Builder(this, "recording").setContentTitle("ReactionRecorder").setContentText("Recording in progress").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}
