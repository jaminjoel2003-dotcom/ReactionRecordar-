package com.reactionrecorder

import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.VideoCompositorSettings

class SideBySideCompositor : VideoCompositorSettings {
    override fun getOutputSize(inputWidths: MutableList<Int>, inputHeights: MutableList<Int>): VideoCompositorSettings.Size {
        val h = inputHeights.maxOrNull() ?: 1080
        return VideoCompositorSettings.Size(h * 16 / 9, h)
    }
    override fun getOverlaySettings(presentationTimeUs: Long, inputIndex: Int): VideoCompositorSettings.OverlaySettings {
        return VideoCompositorSettings.OverlaySettings.Builder().setScale(0.5f, 1f).setTranslation(if (inputIndex == 0) -0.5f else 0.5f, 0f).build()
    }
}
