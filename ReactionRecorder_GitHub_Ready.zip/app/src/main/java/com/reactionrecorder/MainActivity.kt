package com.reactionrecorder

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.content.ContentValues
import android.view.SurfaceView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var player: ExoPlayer
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var sourceUri: Uri? = null
    private var lens = CameraSelector.LENS_FACING_FRONT
    private var cameraProvider: ProcessCameraProvider? = null
    private var cameraFile: File? = null
    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { sourceUri = uri; contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION); player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); findViewById<android.widget.TextView>(com.reactionrecorder.R.id.status).text = "Video selected" }
    }
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { setupCamera() }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main); preview=findViewById(R.id.cameraPreview); player=ExoPlayer.Builder(this).build(); findViewById<androidx.media3.ui.PlayerView>(R.id.sourcePlayer).player=player
        findViewById<android.widget.Button>(R.id.selectButton).setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        findViewById<android.widget.Button>(R.id.switchButton).setOnClickListener { if (recording==null) { lens=if(lens==CameraSelector.LENS_FACING_FRONT) CameraSelector.LENS_FACING_BACK else CameraSelector.LENS_FACING_FRONT; bindCamera() } }
        findViewById<android.widget.Button>(R.id.startButton).setOnClickListener { startRecording() }
        findViewById<android.widget.Button>(R.id.stopButton).setOnClickListener { recording?.stop() }
        if (hasPermissions()) setupCamera() else permissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }
    private fun hasPermissions() = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED
    private fun setupCamera() { ProcessCameraProvider.getInstance(this).also { it.addListener({ cameraProvider=it.get(); bindCamera() }, ContextCompat.getMainExecutor(this)) } }
    private fun bindCamera() { val provider=cameraProvider ?: return; val selector=CameraSelector.Builder().requireLensFacing(lens).build(); val previewUse=Preview.Builder().build().also { it.surfaceProvider=preview.surfaceProvider }; val recorder=Recorder.Builder().setQualitySelector(QualitySelector.fromOrderedList(listOf(Quality.FHD,Quality.HD,Quality.SD))).build(); videoCapture=VideoCapture.withOutput(recorder); provider.unbindAll(); provider.bindToLifecycle(this,selector,previewUse,videoCapture) }
    private fun startRecording() { val uri=sourceUri ?: run { toast("Select a video first"); return }; val vc=videoCapture ?: run { toast("Camera is not ready"); return }; cameraFile=File(cacheDir,"reaction_${System.currentTimeMillis()}.mp4"); val output=FileOutputOptions.Builder(cameraFile!!).build(); ContextCompat.startForegroundService(this, android.content.Intent(this,RecordingForegroundService::class.java)); recording=vc.output.prepareRecording(this,output).withAudioEnabled().start(ContextCompat.getMainExecutor(this)) { event -> when(event) { is VideoRecordEvent.Start -> { findViewById<android.widget.TextView>(R.id.status).text="Recording"; player.seekTo(0); player.play() }; is VideoRecordEvent.Finalize -> { recording=null; stopService(android.content.Intent(this,RecordingForegroundService::class.java)); if(event.hasError()) toast("Recording failed: ${event.error}") else export(uri,cameraFile!!) } } } }
    private fun export(source:Uri,camera:File) { findViewById<android.widget.TextView>(R.id.status).text="Creating final video…"; val out=File(cacheDir,"final_${System.currentTimeMillis()}.mp4"); val src=EditedMediaItem.Builder(MediaItem.fromUri(source)).build(); val cam=EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(camera))).build(); val composition=Composition.Builder(EditedMediaItemSequence(src),EditedMediaItemSequence(cam)).setVideoCompositorSettings(SideBySideCompositor()).build(); val transformer=Transformer.Builder(this).setVideoMimeType("video/avc").setAudioMimeType("audio/mp4a-latm").addListener(object:Transformer.Listener{override fun onCompleted(composition:Composition, exportResult:ExportResult){ saveToGallery(out); findViewById<android.widget.TextView>(R.id.status).text="Saved to Movies/ReactionRecorder" }; override fun onError(composition:Composition, exportResult:ExportResult, exportException:TransformerException){ toast("Export failed: ${exportException.message}") }}).build(); transformer.start(composition,out.absolutePath) }
    private fun saveToGallery(file:File) { val v=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,"Reaction_${System.currentTimeMillis()}.mp4");put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/ReactionRecorder");put(MediaStore.Video.Media.IS_PENDING,1)}; val uri=contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v) ?: return; contentResolver.openOutputStream(uri)?.use{file.inputStream().use{ins->ins.copyTo(it)}}; v.clear();v.put(MediaStore.Video.Media.IS_PENDING,0);contentResolver.update(uri,v,null,null);file.delete() }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    override fun onDestroy(){ recording?.stop(); player.release(); super.onDestroy() }
}
